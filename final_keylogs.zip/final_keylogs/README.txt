============================================================
FINAL DATASET - 262 KEYSTROKE LOG FILES
============================================================

DATASET DESCRIPTION:
----------------------------------------
Total files: 261
File format: *_Verk_log.txt
File naming: [ID]_Verk_log.txt (e.g., 247_Verk_log.txt)

EXCLUSIONS:
----------------------------------------
Files excluded from original dataset: 12
Excluded IDs: 253, 269, 270, 303, 896, 907, 908, 953, 961, 991, 993, 994

Exclusion reasons (as stated in paper):
- Too short (less than a sentence)
- Off-topic
- Data protection issues

WARNINGS:
----------------------------------------
IDs in annotations but NOT found in logs folder: 1
Missing IDs: 892

DATASET CREATION PIPELINE:
----------------------------------------
1. Raw logs collected: 270 files
2. After quality filtering: 262 files
3. Excluded: 253, 269, 270, 303, 896, 907, 908, 953, 961, 991, 993, 994

COMPANION FILES:
----------------------------------------
- Annotations folder: Contains corresponding .tsv annotation files
- Each log file should have a matching annotation file

============================================================
